CREATE VIEW localhistory AS SELECT strftime('%Y-%m-%d %H-%M-%f', history.time, 'localtime') AS localtime, history.account, history.amount FROM history ORDER BY history.time;

